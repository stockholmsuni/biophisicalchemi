#!/usr/bin/python2.7

############ IMPORTS ############

import numpy as np
import argparse
import matplotlib.pyplot as plt


############ CALCS ############

traj = np.loadtxt("traj.dat", dtype=int)
mstates = np.loadtxt("enth.dat")
T = 300

#Count microstate occupation
bins = np.bincount(traj)

#Convert int values to floats and put into a numpy array
simulation_dist = np.array([float(i) for i in bins])
new_simulation_dist = np.array([(simulation_dist[0]+simulation_dist[1]+simulation_dist[2]),simulation_dist[3]])

#Set size of list for the predicted values
prediction_dist = np.zeros(4)

#Predict population using enthalpy values in mstates
new_prediction_dist = np.array([np.exp(1/T),np.exp(200/T)])
#new_prediction_dist = np.array([(prediction_dist[0]+prediction_dist[1]+prediction_dist[2]),prediction_dist[3]])

#Normalize the distributions
#simulation_dist = simulation_dist / sum(simulation_dist)
#prediction_dist = prediction_dist / sum(prediction_dist)

new_simulation_dist = new_simulation_dist / sum(new_simulation_dist)
new_prediction_dist = new_prediction_dist / sum(new_prediction_dist)
#print (new_simulation_dist)
#print (new_prediction_dist)


############ PLOT ############

ind = np.arange(2) # the x locations for the groups
width = 0.35 # the width of the bars

plt.bar(ind, new_prediction_dist, width, color='b',alpha=0.5, label='Predicted')
plt.bar(ind+width, new_simulation_dist, width, color='g',alpha=0.5, label='Simulation')
plt.legend(loc=4)
plt.show()
